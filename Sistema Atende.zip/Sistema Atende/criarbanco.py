import sqlite3

conn = sqlite3.connect('database.db')

cursor = conn.cursor()

#cursor.execute("""CREATE TABLE ticket (
#                       id INTEGER PRIMARY KEY AUTOINCREMENT,
#                       revenda VARCHAR(255) NOT NULL,
#                       reclamacao VARCHAR(255) NOT NULL,
#                       dataabertura DATETIME NOT NULL,
#                       datafechamentro DATETIME NOT NULL,
#                       modelo VARCHAR(255) NOT NULL,
#                       numeroserie INT NOT NULL,
#                       datacompra DATE,
#                       garantia INT,
#                       resolucao VARCHAR(255) NOT NULL,
#                       contato VARCHAR(255) NOT NULL,
#                       estado VARCHAR(255) NOT NULL,
#                       cidade VARCHAR(255) NOT NULL,
#                       autorizada VARCHAR(255) NOT NULL,
#                       mao de obra VARCHAR(20) NOT NULL,
#                       dataretorno DATE,
#                       notafiscal VARCHAR(255) NOT NULL,
#                       frete VARCHAR(20) NOT NULL,
#                       envio VARCHAR(50) NOT NULL,
#                       usuario VARCHAR(255) NOT NULL
#                   )""")
#
#cursor.execute("""CREATE TABLE usuario (
#                       nome VARCHAR(255) NOT NULL,
#                       email VARCHAR(255) PRIMARY KEY NOT NULL,
#                       senha VARCHAR(255) NOT NULL
#                   )""")
#
# print('Tabela criada com sucesso')



conn.close()
