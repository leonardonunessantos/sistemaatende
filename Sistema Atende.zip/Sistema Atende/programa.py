from flask import Flask, request, render_template, g, redirect
import sqlite3
import datetime

app = Flask(__name__)

conn = sqlite3.connect('database.db')
cursor = conn.cursor()

db_url = 'database.db'


@app.before_request
def before_request():
    print('Conectando ao banco')
    # O g guarda a nossa conexão com o banco
    conn = sqlite3.connect(db_url)
    g.conn = conn


@app.teardown_request
def after_request(nada):
    if g.conn is not None:
        g.conn.close()
        print('Desconectando do banco')


@app.route('/')
def index():
    return render_template('abrirticket.html')


@app.route('/abrirticket', methods=['GET'])
def abrirticket():
    # Criar uma classe??
    dt_abertura = datetime.datetime.now()
    revenda = request.form['nome']
    telefone = request.form['telefone']
    estado = request.form['uf']
    cidade = request.form['cidade']
    modelo = request.form['modelo']
    nserie = request.form['nserie']
    dt_compra = request.form['datacompra']
    # Comop pegar a informação do selectbox garantia = request.form['???']
    reclamacao = request.form['reclamacao']
    resolucao = request.form['resolucao']
    autorizada = request.form['autorizada']
    maodeobra = request.form['maodeobra']
    dt_retorno = request.form['dataretorno']
    notafiscal = request.form['notafiscal']
    frete = request.form['frete']
    envio = request.form['envio']
    usuario = request.form['usuario']

    return


app.run(debug=True)
